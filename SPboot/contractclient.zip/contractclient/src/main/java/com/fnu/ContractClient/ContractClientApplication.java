package com.fnu.ContractClient;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ContractClientApplication {

	public static void main(String[] args) {
		SpringApplication.run(ContractClientApplication.class, args);
	}
}
